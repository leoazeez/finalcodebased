#final Code
## this is all the code so far for the Submission system
##make sure the database has been already created

<html>
  <head>
    <title>How to Upload and Open Zip Files With PHP</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  </head>
  <body>
    <div id="container">
    <h1>Upload A Zip File</h1>

	<form  action="questions.php" method="post">
        Username: <input type="text" name="username" /><br />
		Repository Name:<input type="text" name="repository" /><br />
		Access Token: <input type="text" name="token" /><br />
		
        <input type="submit" value="Upload git respository" />
    </form>
 
    </div><!--end container-->
  </body>
</html>